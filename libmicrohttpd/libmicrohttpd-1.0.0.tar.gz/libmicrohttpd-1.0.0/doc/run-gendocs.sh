./gendocs.sh --email libmicrohttpd@gnu.org libmicrohttpd "GNU libmicrohttpd manual"
