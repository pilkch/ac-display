const char *
(*strerror)(void *cls,
            int ec);

see:
gnutls_strerror (ec));
