enum MHD_Bool
(*shutdown_connection)(void *cls,
                       struct MHD_TLS_ConnectionState *cs);

see: MHD_tls_connection_shutdown ()
