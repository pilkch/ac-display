enum MHD_Bool
(*check_record_pending)(void *cls,
                        struct MHD_TLS_ConnectionState *cs);

see:
gnutls_record_check_pending (connection->tls_session)
